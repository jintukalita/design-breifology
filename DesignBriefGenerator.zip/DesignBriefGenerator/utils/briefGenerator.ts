export type DesignType = 'website' | 'app' | 'product';
export type BriefLevel = 'basic' | 'intermediate' | 'advanced';

export const industries = [
  'Technology', 'Healthcare', 'Education', 'Finance', 'Entertainment',
  'Food & Beverage', 'Travel', 'Fashion', 'Sports', 'Real Estate'
];

