import Link from 'next/link'
import { Button } from "@/components/ui/button"

export function NavBar() {
  return (
    <nav className="bg-background border-b border-border">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <Link href="/" className="text-xl font-semibold text-primary">
          Design Brief Generator
        </Link>
        <div className="space-x-2">
          <Button variant="ghost" asChild className="text-primary hover:text-primary hover:bg-primary/10">
            <Link href="/">Home</Link>
          </Button>
          <Button variant="ghost" asChild className="text-primary hover:text-primary hover:bg-primary/10">
            <Link href="/saved-briefs">Saved Briefs</Link>
          </Button>
        </div>
      </div>
    </nav>
  )
}

