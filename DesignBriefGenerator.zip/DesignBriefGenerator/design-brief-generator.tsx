'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { industries, DesignType, BriefLevel } from './utils/briefGenerator'
import { jsPDF } from "jspdf"
import { cn } from "@/lib/utils"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { Moon, Sun } from 'lucide-react'

export default function DesignBriefGenerator() {
  const [industry, setIndustry] = useState<string>(industries[0])
  const [customIndustry, setCustomIndustry] = useState<string>('')
  const [designType, setDesignType] = useState<DesignType>('website')
  const [briefLevel, setBriefLevel] = useState<BriefLevel>('basic')
  const [brief, setBrief] = useState<string>('')
  const [briefHistory, setBriefHistory] = useState<string[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(false)

  useEffect(() => {
    const savedBriefs = localStorage.getItem('briefHistory')
    if (savedBriefs) {
      setBriefHistory(JSON.parse(savedBriefs))
    }
  }, [])

  const handleGenerate = async () => {
    setIsGenerating(true)
    const selectedIndustry = industry === 'custom' ? customIndustry : industry
    
    try {
      const { text } = await generateText({
        model: openai("gpt-4-turbo"),
        prompt: `Generate a ${briefLevel} design brief for a ${designType} in the ${selectedIndustry} industry. Include specific details about the project goals, target audience, key features, and any other relevant information for a ${briefLevel} level brief.`
      })

      setBrief(text)
      const updatedHistory = [text, ...briefHistory].slice(0, 5)
      setBriefHistory(updatedHistory)
      localStorage.setItem('briefHistory', JSON.stringify(updatedHistory))
    } catch (error) {
      console.error('Error generating brief:', error)
      setBrief('An error occurred while generating the brief. Please try again.')
    } finally {
      setIsGenerating(false)
    }
  }

  const handleSave = () => {
    localStorage.setItem('savedBrief', brief)
    alert('Brief saved successfully!')
  }

  const handleLoad = () => {
    const savedBrief = localStorage.getItem('savedBrief')
    if (savedBrief) {
      setBrief(savedBrief)
    } else {
      alert('No saved brief found.')
    }
  }

  const handleExportPDF = () => {
    const doc = new jsPDF()
    doc.text(brief, 10, 10)
    doc.save('design-brief.pdf')
  }

  const handleShare = () => {
    const briefData = btoa(JSON.stringify({ industry, designType, briefLevel, brief }))
    const shareUrl = `${window.location.origin}?brief=${briefData}`
    navigator.clipboard.writeText(shareUrl)
    alert('Share URL copied to clipboard!')
  }

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode)
  }

  return (
    <div className={cn(
      "min-h-screen p-4 font-sans transition-colors duration-200",
      isDarkMode ? "dark bg-gray-900" : "bg-gray-100"
    )}>
      <Card className="w-full max-w-2xl mx-auto border-gray-200 dark:border-gray-700 shadow-md">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-2xl font-bold">AI-Powered Design Brief Generator</CardTitle>
            <CardDescription>Generate tailored design briefs using AI for websites, apps, or products</CardDescription>
          </div>
          <Button variant="ghost" size="icon" onClick={toggleDarkMode}>
            {isDarkMode ? <Sun className="h-6 w-6" /> : <Moon className="h-6 w-6" />}
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="industry">Industry</Label>
            <Select value={industry} onValueChange={setIndustry}>
              <SelectTrigger id="industry">
                <SelectValue placeholder="Select an industry" />
              </SelectTrigger>
              <SelectContent>
                {industries.map((ind) => (
                  <SelectItem key={ind} value={ind}>{ind}</SelectItem>
                ))}
                <SelectItem value="custom">Custom</SelectItem>
              </SelectContent>
            </Select>
            {industry === 'custom' && (
              <Input
                type="text"
                placeholder="Enter custom industry"
                value={customIndustry}
                onChange={(e) => setCustomIndustry(e.target.value)}
              />
            )}
          </div>
          <div className="space-y-2">
            <Label>Design Type</Label>
            <RadioGroup value={designType} onValueChange={(value: DesignType) => setDesignType(value)}>
              <div className="flex space-x-4">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="website" id="website" />
                  <Label htmlFor="website">Website</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="app" id="app" />
                  <Label htmlFor="app">App</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="product" id="product" />
                  <Label htmlFor="product">Product</Label>
                </div>
              </div>
            </RadioGroup>
          </div>
          <div className="space-y-2">
            <Label>Brief Level</Label>
            <RadioGroup value={briefLevel} onValueChange={(value: BriefLevel) => setBriefLevel(value)}>
              <div className="flex space-x-4">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="basic" id="basic" />
                  <Label htmlFor="basic">Basic</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="intermediate" id="intermediate" />
                  <Label htmlFor="intermediate">Intermediate</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="advanced" id="advanced" />
                  <Label htmlFor="advanced">Advanced</Label>
                </div>
              </div>
            </RadioGroup>
          </div>
          <Button 
            onClick={handleGenerate}
            disabled={isGenerating}
          >
            {isGenerating ? 'Generating...' : 'Generate AI Brief'}
          </Button>
          {brief && (
            <div className="mt-6 p-4 bg-gray-100 dark:bg-gray-800 rounded-md border border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold mb-2">Generated AI Brief:</h3>
              <pre className="whitespace-pre-wrap text-sm">{brief}</pre>
              <div className="mt-4 space-x-2">
                <Button onClick={handleSave}>Save Brief</Button>
                <Button onClick={handleExportPDF}>Export to PDF</Button>
                <Button onClick={handleShare}>Share Brief</Button>
              </div>
            </div>
          )}
          <div>
            <Button onClick={handleLoad}>Load Saved Brief</Button>
          </div>
          {briefHistory.length > 0 && (
            <div className="mt-6">
              <h3 className="text-lg font-semibold mb-2">Brief History:</h3>
              <ul className="space-y-2">
                {briefHistory.map((historyBrief, index) => (
                  <li 
                    key={index} 
                    className="cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700 p-2 rounded border border-gray-200 dark:border-gray-700" 
                    onClick={() => setBrief(historyBrief)}
                  >
                    {historyBrief.split('\n')[0]}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <p className="text-sm text-muted-foreground">Use this AI-powered tool to generate tailored design briefs for inspiration or practice.</p>
        </CardFooter>
      </Card>
    </div>
  )
}

