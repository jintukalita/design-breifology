export type DesignType = 'website' | 'app' | 'product';
export type BriefLevel = 'basic' | 'intermediate' | 'advanced';

export const industries = [
  'Technology',
  'Healthcare',
  'Education',
  'Finance',
  'Entertainment',
  'Food & Beverage',
  'Travel',
  'Fashion',
  'Sports',
  'Real Estate'
];

const briefTemplates = {
  website: {
    basic: "Create a user-friendly website for {industry} that showcases key information and services. Focus on a clean design with easy navigation.",
    intermediate: "Design a responsive website for {industry} with interactive elements. Include a homepage, about us, services, and contact pages. Implement a cohesive color scheme and typography.",
    advanced: "Develop a cutting-edge website for {industry} with advanced features such as user accounts, real-time updates, and integration with third-party APIs. Ensure mobile responsiveness and implement SEO best practices."
  },
  app: {
    basic: "Design a simple mobile app for {industry} that allows users to access basic information and services. Focus on intuitive navigation and essential features.",
    intermediate: "Create a cross-platform app for {industry} with a customizable user interface. Include push notifications, data synchronization, and basic analytics.",
    advanced: "Develop a feature-rich app for {industry} with advanced capabilities such as offline mode, AI-powered recommendations, and seamless integration with wearable devices. Implement robust security measures and ensure scalability."
  },
  product: {
    basic: "Design a functional product for {industry} that addresses a specific need. Focus on ergonomics and user-friendly features.",
    intermediate: "Create an innovative product for {industry} with multiple features. Consider sustainability in materials and manufacturing processes. Include a user manual and packaging design.",
    advanced: "Develop a high-end product for {industry} with cutting-edge technology. Incorporate IoT capabilities, customizable components, and a companion mobile app. Consider the entire product lifecycle, including maintenance and upgrades."
  }
};

export function generateBrief(industry: string, designType: DesignType, briefLevel: BriefLevel): string {
  const template = briefTemplates[designType][briefLevel];
  return template.replace('{industry}', industry);
}

