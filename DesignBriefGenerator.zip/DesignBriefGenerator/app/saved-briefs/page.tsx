'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import Link from 'next/link'

interface SavedBrief {
  id: string;
  content: string;
  timestamp: number;
}

export default function SavedBriefs() {
  const [savedBriefs, setSavedBriefs] = useState<SavedBrief[]>([])
  const [selectedBrief, setSelectedBrief] = useState<SavedBrief | null>(null)

  useEffect(() => {
    const briefs = JSON.parse(localStorage.getItem('savedBriefs') || '[]')
    setSavedBriefs(briefs)
  }, [])

  const handleDelete = (id: string) => {
    const updatedBriefs = savedBriefs.filter(brief => brief.id !== id)
    setSavedBriefs(updatedBriefs)
    localStorage.setItem('savedBriefs', JSON.stringify(updatedBriefs))
    if (selectedBrief?.id === id) {
      setSelectedBrief(null)
    }
  }

  return (
    <div className="container mx-auto p-4">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>Saved Briefs</CardTitle>
          <CardDescription>View and manage your saved design briefs</CardDescription>
        </CardHeader>
        <CardContent className="flex gap-4">
          <div className="w-1/3">
            <ScrollArea className="h-[600px] w-full rounded-md border p-4">
              {savedBriefs.map((brief) => (
                <div key={brief.id} className="mb-4 p-2 border rounded cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800" onClick={() => setSelectedBrief(brief)}>
                  <h3 className="font-semibold">{new Date(brief.timestamp).toLocaleString()}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{brief.content.substring(0, 50)}...</p>
                </div>
              ))}
            </ScrollArea>
          </div>
          <div className="w-2/3">
            {selectedBrief ? (
              <div>
                <h2 className="text-xl font-bold mb-2">Selected Brief</h2>
                <p className="mb-4 text-sm text-gray-500 dark:text-gray-400">{new Date(selectedBrief.timestamp).toLocaleString()}</p>
                <ScrollArea className="h-[500px] w-full rounded-md border p-4 mb-4">
                  <pre className="whitespace-pre-wrap">{selectedBrief.content}</pre>
                </ScrollArea>
                <Button variant="destructive" onClick={() => handleDelete(selectedBrief.id)}>Delete Brief</Button>
              </div>
            ) : (
              <p>Select a brief to view its content</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

