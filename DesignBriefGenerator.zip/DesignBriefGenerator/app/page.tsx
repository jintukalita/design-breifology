'use client'

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { industries, DesignType, BriefLevel, generateBrief } from '@/app/utils/briefGenerator'
import { jsPDF } from "jspdf"
import { cn } from "@/lib/utils"
import { Moon, Sun } from 'lucide-react'
import { NavBar } from '@/components/nav-bar'

export default function DesignBriefGenerator() {
  const [industry, setIndustry] = useState<string>(industries[0])
  const [customIndustry, setCustomIndustry] = useState<string>('')
  const [designType, setDesignType] = useState<DesignType>('website')
  const [briefLevel, setBriefLevel] = useState<BriefLevel>('basic')
  const [brief, setBrief] = useState<string>('')
  const [briefHistory, setBriefHistory] = useState<string[]>([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(false)

  useEffect(() => {
    const savedBriefs = localStorage.getItem('briefHistory')
    if (savedBriefs) {
      setBriefHistory(JSON.parse(savedBriefs))
    }
  }, [])

  const handleGenerate = () => {
    setIsGenerating(true)
    const selectedIndustry = industry === 'custom' ? customIndustry : industry
    
    const generatedBrief = generateBrief(selectedIndustry, designType, briefLevel)

    setBrief(generatedBrief)
    const updatedHistory = [generatedBrief, ...briefHistory].slice(0, 5)
    setBriefHistory(updatedHistory)
    localStorage.setItem('briefHistory', JSON.stringify(updatedHistory))
    setIsGenerating(false)
  }

  const handleSave = () => {
    const savedBriefs = JSON.parse(localStorage.getItem('savedBriefs') || '[]')
    const newBrief = {
      id: Date.now().toString(),
      content: brief,
      timestamp: Date.now()
    }
    savedBriefs.push(newBrief)
    localStorage.setItem('savedBriefs', JSON.stringify(savedBriefs))
    alert('Brief saved successfully!')
  }

  const handleExportPDF = () => {
    const doc = new jsPDF()
    doc.text(brief, 10, 10)
    doc.save('design-brief.pdf')
  }

  const handleShare = () => {
    const briefData = btoa(JSON.stringify({ industry, designType, briefLevel, brief }))
    const shareUrl = `${window.location.origin}?brief=${briefData}`
    navigator.clipboard.writeText(shareUrl)
    alert('Share URL copied to clipboard!')
  }

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode)
  }

  return (
    <div className={cn(
      "min-h-screen font-sans transition-colors duration-200",
      isDarkMode ? "dark bg-background" : "bg-background"
    )}>
      <NavBar />
      <div className="container mx-auto p-4">
        <Card className="w-full max-w-2xl mx-auto border-border shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between bg-muted/50">
            <div>
              <CardTitle className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Design Brief Generator
              </CardTitle>
              <CardDescription className="text-muted-foreground">
                Generate tailored design briefs for websites, apps, or products
              </CardDescription>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleDarkMode}
              className="hover:bg-muted"
            >
              {isDarkMode ? <Sun className="h-6 w-6" /> : <Moon className="h-6 w-6" />}
            </Button>
          </CardHeader>
          <CardContent className="space-y-6 pt-6">
            <div className="space-y-2">
              <Label htmlFor="industry" className="text-foreground">Industry</Label>
              <Select value={industry} onValueChange={setIndustry}>
                <SelectTrigger id="industry" className="border-input">
                  <SelectValue placeholder="Select an industry" />
                </SelectTrigger>
                <SelectContent>
                  {industries.map((ind) => (
                    <SelectItem key={ind} value={ind}>{ind}</SelectItem>
                  ))}
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
              {industry === 'custom' && (
                <Input
                  type="text"
                  placeholder="Enter custom industry"
                  value={customIndustry}
                  onChange={(e) => setCustomIndustry(e.target.value)}
                  className="border-input"
                />
              )}
            </div>
            <div className="space-y-2">
              <Label className="text-foreground">Design Type</Label>
              <RadioGroup value={designType} onValueChange={(value: DesignType) => setDesignType(value)}>
                <div className="flex space-x-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="website" id="website" />
                    <Label htmlFor="website">Website</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="app" id="app" />
                    <Label htmlFor="app">App</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="product" id="product" />
                    <Label htmlFor="product">Product</Label>
                  </div>
                </div>
              </RadioGroup>
            </div>
            <div className="space-y-2">
              <Label className="text-foreground">Brief Level</Label>
              <RadioGroup value={briefLevel} onValueChange={(value: BriefLevel) => setBriefLevel(value)}>
                <div className="flex space-x-4">
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="basic" id="basic" />
                    <Label htmlFor="basic">Basic</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="intermediate" id="intermediate" />
                    <Label htmlFor="intermediate">Intermediate</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="advanced" id="advanced" />
                    <Label htmlFor="advanced">Advanced</Label>
                  </div>
                </div>
              </RadioGroup>
            </div>
            <Button 
              onClick={handleGenerate}
              disabled={isGenerating}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              {isGenerating ? 'Generating...' : 'Generate Brief'}
            </Button>
            {brief && (
              <div className="mt-6 p-4 bg-muted rounded-md border border-border">
                <h3 className="text-lg font-semibold mb-2 text-foreground">Generated Brief:</h3>
                <p className="whitespace-pre-wrap text-sm text-foreground/90">{brief}</p>
                <div className="mt-4 space-x-2">
                  <Button onClick={handleSave} variant="outline" className="border-primary hover:bg-primary hover:text-primary-foreground">
                    Save Brief
                  </Button>
                  <Button onClick={handleExportPDF} variant="outline" className="border-primary hover:bg-primary hover:text-primary-foreground">
                    Export to PDF
                  </Button>
                  <Button onClick={handleShare} variant="outline" className="border-primary hover:bg-primary hover:text-primary-foreground">
                    Share Brief
                  </Button>
                </div>
              </div>
            )}
            {briefHistory.length > 0 && (
              <div className="mt-6">
                <h3 className="text-lg font-semibold mb-2 text-foreground">Brief History:</h3>
                <ul className="space-y-2">
                  {briefHistory.map((historyBrief, index) => (
                    <li 
                      key={index} 
                      className="cursor-pointer hover:bg-muted p-2 rounded border border-border transition-colors duration-200" 
                      onClick={() => setBrief(historyBrief)}
                    >
                      {historyBrief.split('\n')[0]}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between bg-muted/50">
            <p className="text-sm text-muted-foreground">
              Use this tool to generate tailored design briefs for inspiration or practice.
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

